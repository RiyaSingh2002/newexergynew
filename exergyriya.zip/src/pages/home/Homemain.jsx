// import React from 'react'

import Footer from "../components/Footer"
import New from "./new"

const Homemain = () => {
  return (
    <div>
            <New/>
            <Footer/>
    </div>
  )
}

export default Homemain